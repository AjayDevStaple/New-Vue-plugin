<template>
  <h2>Settings Page</h2>
</template>

<script lang="ts">
export default {
  name: 'SettingsPage',
  components: {},
}
</script>

<style>

</style>