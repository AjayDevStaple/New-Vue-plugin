<template>
<h1>See Clinic</h1>

</template>

<script lang="ts">

export default {
  name: 'SeeClinic',
  components: {},
  methods: {},
  data() {
    return {
      value: 0
    }
  }
}
</script>

<style>

</style>