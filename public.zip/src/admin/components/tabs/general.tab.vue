<template>
  <div id="wpvk-general-setting-tab" class="tab-container">
    <h2>General Tab</h2>
  </div>
</template>

<script lang="ts">
export default {
  name: 'GeneralTab',
  components: {}
}
</script>

<style>

</style>