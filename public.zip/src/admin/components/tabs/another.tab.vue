<template>
  <div class="tab-container">
    <h2>Another Tab</h2>
  </div>
</template>

<script lang="ts">
export default {
  name: 'AnotherTab',
  components: {},
}
</script>

<style>

</style>