<template>
  <ul class="tab-menu">
    <li>
      <router-link to="/">General</router-link>
    </li>
    <li>
      <router-link to="/another">Another</router-link>
    </li>
  </ul>
</template>

<script lang="ts">
export default {
  name: 'TabNavigation',
  components: {},
}
</script>

<style>

</style>